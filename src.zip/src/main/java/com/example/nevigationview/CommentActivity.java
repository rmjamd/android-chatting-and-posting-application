package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.database.SnapshotParser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class CommentActivity extends AppCompatActivity {

    private EditText comment_text;
    private ImageButton comment_button;
    private RecyclerView comment_list;
    private String postkey;
    private DatabaseReference userref,postref;
    private FirebaseAuth mauth;
    private String uid;
    FirebaseRecyclerAdapter<Comments,CommentViewHolder> adapter;
    Query query;
    private Toolbar mtoolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_comment);


        mauth=FirebaseAuth.getInstance();
        uid=mauth.getCurrentUser().getUid();
        userref= FirebaseDatabase.getInstance().getReference().child("Users");
        mtoolbar=findViewById(R.id.comment_toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Comment");
        mtoolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });


        postkey= (String) getIntent().getExtras().get("PostKey");
        postref=FirebaseDatabase.getInstance().getReference().child("Posts").child(postkey).child("comments");
        query=FirebaseDatabase.getInstance().getReference().child("Posts").child(postkey).child("comments");
        comment_text=findViewById(R.id.comment_text);
        comment_button=findViewById(R.id.comment_post);
        comment_list=findViewById(R.id.comment_list);
        comment_list.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        comment_list.setLayoutManager(linearLayoutManager);
        comment_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               userref.child(uid).addValueEventListener(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                       if(dataSnapshot.exists())
                       {
                           if(!comment_text.getText().toString().isEmpty())
                           {
                               String username=dataSnapshot.child("username").getValue().toString();
                               String img=dataSnapshot.child("profileimage").getValue().toString();
                               add_comment(username,comment_text.getText().toString(),img);
                           }
                           else
                           {
                               Toast.makeText(CommentActivity.this, "Plz write your comment.", Toast.LENGTH_SHORT).show();
                           }
                           comment_text.setText("");
                       }
                   }

                   @Override
                   public void onCancelled(@NonNull DatabaseError databaseError) {

                   }
               });

            }
        });
        DisplayComments();

    }

    private void DisplayComments()
    {

        FirebaseRecyclerOptions<Comments> options=new FirebaseRecyclerOptions.Builder<Comments>().setQuery(query, new SnapshotParser<Comments>() {
            @NonNull
            @Override
            public Comments parseSnapshot(@NonNull DataSnapshot snapshot) {
                return new Comments(snapshot.child("comment").getValue().toString(),
                        snapshot.child("date").getValue().toString(),
                        snapshot.child("time").getValue().toString(),
                        snapshot.child("username").getValue().toString(),
                        snapshot.child("profileimage").getValue().toString()
                );
            }
        }).build();
        adapter=new FirebaseRecyclerAdapter<Comments, CommentViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull CommentViewHolder holder, int position, @NonNull Comments model)
            {
                holder.setComment(model.getComment());
                holder.setDate(model.getDate());
                holder.setTime(model.getTime());
                holder.setProfileimage(model.getProfileimage());
                holder.setUsername(model.getUsername());
            }
            @NonNull
            @Override
            public CommentViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.all_comment_display_layout, parent, false);
                return new CommentViewHolder(view);
            }
        };
        comment_list.setAdapter(adapter);

    }
    public static class CommentViewHolder extends RecyclerView.ViewHolder
    {
        View mview;
        public CommentViewHolder(@NonNull View itemView) {
            super(itemView);
            mview = itemView;
        }
        public void setComment(String comment) {
            TextView t=mview.findViewById(R.id.comment_text);
            t.setText(comment);
        }
        public void setDate(String date) {
            TextView t=mview.findViewById(R.id.comment_date);
            t.setText(date);
        }
        public void setTime(String time) {
            TextView t=mview.findViewById(R.id.comment_time);
            t.setText(time);
        }
        public void setUsername(String username) {
            TextView t=mview.findViewById(R.id.comment_username);
            t.setText(username);
        }
        public void setProfileimage(String profileimage) {
            CircleImageView image = (CircleImageView) mview.findViewById(R.id.comment_profile_pic);
            Picasso.get().load(profileimage).placeholder(R.drawable.profile).into(image);
        }
    }
    private void add_comment(String username,String text,String profileimage) {
        Calendar date=Calendar.getInstance();
        SimpleDateFormat currentdate=new SimpleDateFormat("dd-MMMM-yyyy");
        String savecurrdate=currentdate.format(date.getTime());

        Calendar time=Calendar.getInstance();
        SimpleDateFormat currenttime=new SimpleDateFormat( "HH:mm");
        String savecurrtime=currenttime.format(time.getTime());

        SimpleDateFormat currtime=new SimpleDateFormat( "HH:mm:ss");
        String savecurr=currtime.format(time.getTime());
        String commentname=uid+savecurrdate+savecurr;

        HashMap m = new HashMap();
        m.put("uid", uid);
        m.put("comment",text);
        m.put("date", savecurrdate);
        m.put("time", savecurrtime);
        m.put("username", username);
        m.put("profileimage",profileimage);
        postref.child(commentname).updateChildren(m).addOnCompleteListener(new OnCompleteListener() {
            @Override
            public void onComplete(@NonNull Task task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(CommentActivity.this, "Comment Successfull", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(CommentActivity.this, "Error: "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    @Override
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }

}
