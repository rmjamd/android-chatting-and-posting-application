package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class ProfileActivity extends AppCompatActivity {

    private ImageView profileimage;
    private TextView username,fullname,status,dob,relationship,country;
    FirebaseAuth mauth;
    DatabaseReference userref,postref,countfriendref;
    private Button mypost,myfriend;
    String uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        profileimage=findViewById(R.id.my_profile_pic);
        username=findViewById(R.id.my_username);
        fullname=findViewById(R.id.my_fullname);
        country=findViewById(R.id.my_country);
        dob=findViewById(R.id.my_dob);
        relationship=findViewById(R.id.my_relationship_status);
        status=findViewById(R.id.my_status);
        mauth=FirebaseAuth.getInstance();
        uid=mauth.getCurrentUser().getUid();
        myfriend=findViewById(R.id.my_friends);
        mypost=findViewById(R.id.my_post);
        userref=FirebaseDatabase.getInstance().getReference().child("Users").child(uid);
        postref=FirebaseDatabase.getInstance().getReference().child("Posts");
        countfriendref=FirebaseDatabase.getInstance().getReference().child("Friends").child(uid);
        setallValues();
        countfriendref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    int count= (int) dataSnapshot.getChildrenCount();
                    myfriend.setText(Integer.toString(count)+" friends");
                }
                else
                {
                    myfriend.setText("0 friends");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        postref.orderByChild("uid").startAt(uid).endAt(uid+"\uf8ff").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    int count= (int) dataSnapshot.getChildrenCount();
                    mypost.setText(Integer.toString(count)+" posts");

                }
                else
                {
                    mypost.setText("0 posts");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        myfriend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileActivity.this,FriendsActivity.class));
            }
        });
        mypost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ProfileActivity.this,MyPostActivity.class));
            }
        });
    }
    private void setallValues() {
        userref.addValueEventLi tener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("username"))
                username.setText(dataSnapshot.child("username").getValue().toString());
                if(dataSnapshot.hasChild("fullname"))
                fullname.setText(dataSnapshot.child("fullname").getValue().toString());
                if(dataSnapshot.hasChild("country"))
                country.setText("Country:  "+dataSnapshot.child("country").getValue().toString());
                if(dataSnapshot.hasChild("status"))
                status.setText(dataSnapshot.child("status").getValue().toString());
                if(dataSnapshot.hasChild("dob"))
                dob.setText("Date of Birth:  "+dataSnapshot.child("dob").getValue().toString());
                if(dataSnapshot.hasChild("relationshipstatus"))
                relationship.setText("Relationship Status:  "+dataSnapshot.child("relationshipstatus").getValue().toString());
                if(dataSnapshot.hasChild("profileimage"))
                Picasso.get().load(dataSnapshot.child("profileimage").getValue().toString()).placeholder(R.drawable.profile).into(profileimage);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }


}
