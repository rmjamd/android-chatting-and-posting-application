package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class RegisterActivity extends AppCompatActivity {

    private EditText email,password,confirmpassword;
    private Button register;
    private FirebaseAuth mauth;
    private ProgressDialog loading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
         super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        email=findViewById(R.id.register_email);
        password=findViewById(R.id.register_password);
        confirmpassword=findViewById(R.id.register_confirm_password);
        register=findViewById(R.id.register_create_account);
        mauth=FirebaseAuth.getInstance();
        loading=new ProgressDialog(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });

    }
    @Override
    protected void onStart() {
        super.onStart();
        if(mauth.getCurrentUser()!=null) {
            Intent i = new Intent(RegisterActivity.this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        }

    }
    private void registerUser()
    {
         String e=email.getText().toString();
         String p=password.getText().toString();
         String cp=confirmpassword.getText().toString();
         if(e.isEmpty())
         {
             Toast.makeText(this,"Please Write Your Email",Toast.LENGTH_LONG).show();
         }
         else if(p.isEmpty())
         {
             Toast.makeText(this,"Please Write Your Password",Toast.LENGTH_LONG).show();
         }
         else if(cp.isEmpty())
         {
             Toast.makeText(this,"Please Write Your Confirm Password",Toast.LENGTH_LONG).show();
         }
         else if(p.length()<6)
         {
             Toast.makeText(this,"Password is too Short",Toast.LENGTH_LONG).show();
         }
         else if(!p.equals(cp))
         {
             Toast.makeText(this,"Password is not matched",Toast.LENGTH_LONG).show();
         }
         else
         {
             loading.setTitle("Creating New Account");
             loading.setMessage("Please Wait!!");
             loading.show();
             loading.setCanceledOnTouchOutside(true);        //it will show untill register successfully or any error occured
             mauth.createUserWithEmailAndPassword(e,p).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                 @Override
                 public void onComplete(@NonNull Task<AuthResult> task) {
                     if(task.isSuccessful())
                     {

                         sendemail();
                         loading.dismiss();


                     }
                     else
                     {
                         String message =task.getException().getMessage();
                         Toast.makeText(RegisterActivity.this,"Error: "+message,Toast.LENGTH_LONG).show();
                         loading.dismiss();
                     }
                 }
             });
         }
    }
    private void sendemail()
    {
        FirebaseUser user=mauth.getCurrentUser();
        if(user !=null)
        {
            user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful())
                    {
                        Toast.makeText(RegisterActivity.this,"You Are Authenticated Successfully",Toast.LENGTH_LONG).show();
                        Intent i=new Intent(RegisterActivity.this,LoginActivity.class);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                    }
                    else
                    {
                        Toast.makeText(RegisterActivity.this, "Error : "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }


}
