package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
//import com.google.firebase.database.core.view.View;
import com.squareup.picasso.Picasso;

public class FindActivity extends AppCompatActivity {
    private Toolbar mtoolbar;
    private EditText search_text;
    private ImageButton search_button;
    private String text;
    FirebaseRecyclerAdapter<Search_friend,SearchViewHolder> adapter;
    private  RecyclerView friendlist;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find);
        mtoolbar=findViewById(R.id.friend_toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Find Friends");
        mtoolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(adapter!=null)
                adapter.stopListening();
                finish();

            }
        });
        friendlist=findViewById(R.id.friend_list);
        friendlist.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        friendlist.setLayoutManager(linearLayoutManager);
        search_text=findViewById(R.id.friend_search);
        search_button=findViewById(R.id.friend_search_button);

        search_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                text=search_text.getText().toString();
                show_frind();
            }
        });
    }

    private void show_frind() {
        Query query= FirebaseDatabase.getInstance().getReference().child("Users").orderByChild("fullname").startAt(text).endAt(text+ "\uf8ff");
    //    Query query=FirebaseDatabase.getInstance().getReference().child("Users");
        FirebaseRecyclerOptions<Search_friend> options =new FirebaseRecyclerOptions.Builder<Search_friend>().setQuery(query, new SnapshotParser<Search_friend>() {
            @NonNull
            @Override
            public Search_friend parseSnapshot(@NonNull DataSnapshot snapshot) {
                return new Search_friend(snapshot.child("profileimage").getValue().toString(),snapshot.child("fullname").getValue().toString(),snapshot.child("status").getValue().toString());
            }
        }).build();
        adapter= new FirebaseRecyclerAdapter<Search_friend, SearchViewHolder>(options) {
            @NonNull
            @Override
            public SearchViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.all_users_display_layout, parent, false);

                return new SearchViewHolder(view);
            }

            @Override
            protected void onBindViewHolder(@NonNull SearchViewHolder holder, int position, @NonNull Search_friend model) {
                final String uid=getRef(position).getKey();
                holder.setFullname(model.getFullname());
                holder.setProfileimage(model.getProfileimage());
                holder.setStatus(model.getStatus());
                holder.view.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i=new Intent(FindActivity.this,PersonProfileActivity.class);
                        i.putExtra("userid",uid);
                        startActivity(i);
                    }
                });
            }
        };
        friendlist.setAdapter(adapter);
        adapter.startListening();
    }
    public static class SearchViewHolder extends RecyclerView.ViewHolder
    {

        View view;
        public SearchViewHolder(@NonNull View itemView) {
            super(itemView);
            view = itemView;
        }
        public void setProfileimage(String profileimage) {
            ImageView PostImage = (ImageView) view.findViewById(R.id.all_user_profile_image);
            Picasso.get().load(profileimage).placeholder(R.drawable.profile).into(PostImage);
        }
        public void setFullname(String fullname) {
            TextView t=(TextView)view.findViewById(R.id.all_user_fullname);
            t.setText(fullname);
        }
        public void setStatus(String status) {
            TextView t=(TextView)view.findViewById(R.id.all_user_status);
            t.setText(status);
        }
    }
    @Override
    protected void onStart() {
        super.onStart();

    }


}


