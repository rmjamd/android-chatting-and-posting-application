package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

public class LoginActivity extends AppCompatActivity {

    private TextView e,forgetpassord;
    private EditText email, password;
    private Button login;
    private FirebaseAuth mauth;
    private ProgressDialog loading;
    private  boolean emailflag;
    private ImageView signin;
    private static final int RC_SIGN_IN=1;
    private GoogleApiClient googleApiClient;
    private static  final String TAG="LoginActivity";


    @SuppressLint("WrongViewCast")

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        e = findViewById(R.id.login_register);

        e.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(LoginActivity.this, RegisterActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(i);
                finish();

            }
        });
        signin=findViewById(R.id.login_googlesignin);
        forgetpassord=findViewById(R.id.login_forgetPassword);
        email = findViewById(R.id.login_email);
        password = findViewById(R.id.login_password);
        login = findViewById(R.id.login_button);
        mauth = FirebaseAuth.getInstance();
        loading = new ProgressDialog(this);
        forgetpassord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,ForgetPasswordActivity.class));
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerUser();
            }
        });
        // Configure Google Sign In
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        googleApiClient=new GoogleApiClient.Builder(this).enableAutoManage(this, new GoogleApiClient.OnConnectionFailedListener() {
            @Override
            public void onConnectionFailed(@NonNull ConnectionResult connectionResult)
            {
                Toast.makeText(LoginActivity.this, "Connection to Google Sign in failed...", Toast.LENGTH_SHORT).show();
            }
        })
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                signIn();
            }
        });
    }
    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(googleApiClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            loading.setTitle("google Sign In");
            loading.setMessage("Please wait, while we are allowing you to login using your Google Account...");
            loading.setCanceledOnTouchOutside(true);
            loading.show();

            GoogleSignInResult result=Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if(result.isSuccess())
            {
                GoogleSignInAccount account=result.getSignInAccount();
                firebaseAuthWithGoogle(account);
                Toast.makeText(this, "please wait,we are getting your auth result", Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(this, "can't getyour auth result", Toast.LENGTH_SHORT).show();
                loading.dismiss();
            }
        }
    }
    private void firebaseAuthWithGoogle(GoogleSignInAccount idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken.getIdToken(), null);
        mauth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Log.d(TAG, "signInWithCredential:success");
                            startActivity(new Intent(LoginActivity.this,MainActivity.class));
                            loading.dismiss();

                        } else {

                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            startActivity(new Intent(LoginActivity.this,LoginActivity.class));
                            Toast.makeText(LoginActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            loading.dismiss();

                        }

                    }
                });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if(mauth.getCurrentUser()!=null) {
            Intent i = new Intent(LoginActivity.this, MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        }

    }
    private void registerUser() {
        String e=email.getText().toString();
        String p=password.getText().toString();
        if(e.isEmpty())
        {
            Toast.makeText(this,"Please Write Your Email",Toast.LENGTH_LONG).show();
        }
        else if(p.isEmpty())
        {
            Toast.makeText(this,"Please Write Your Password",Toast.LENGTH_LONG).show();
        }
        else
        {
            loading.setTitle("Login");
            loading.setMessage("Please Wait!!");
            loading.show();
            loading.setCanceledOnTouchOutside(true);//it will show untill register successfully or any error occured

            mauth.signInWithEmailAndPassword(e,p).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful())
                    {
                        veryfyemail();
                        loading.dismiss();
                    }
                    else
                    {

                        String message =task.getException().getMessage();
                        Toast.makeText(LoginActivity.this,"Error: "+message,Toast.LENGTH_LONG).show();
                        loading.dismiss();
                    }
                }
            });



        }
    }

    private void veryfyemail() {
        FirebaseUser user=mauth.getCurrentUser();
        emailflag=user.isEmailVerified();
        if(emailflag)
        {
            Toast.makeText(LoginActivity.this,"You Are logged in  Successfully",Toast.LENGTH_LONG).show();
            Intent i=new Intent(LoginActivity.this,MainActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
            finish();
        }
        else
        {

            Toast.makeText(this, "please verify your email first", Toast.LENGTH_SHORT).show();
            mauth.signOut();
        }
    }
}
