package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.ProgressDialog;
import android.content.Intent;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class PostActivity extends AppCompatActivity {

    private FirebaseAuth mauth;
    private FirebaseDatabase postdatabase;
    private Toolbar mtoolbar;
    private ImageButton SelectPostButton;
    private Button UpdatePostButton;
    private EditText PostDescription;
    final static int gallerypic=1;
    private Uri imageUri;
    private String savecurrdate,savecurrtime,postname;
    private String userid;
    private StorageReference postref;
    private DatabaseReference UserRef;
    private DatabaseReference databasepostref;
    private  String downloadurl;
    private ProgressDialog loading;
    private String userfullname,profile,description_post;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
         setContentView(R.layout.activity_post);
        mauth=FirebaseAuth.getInstance();

        loading=new ProgressDialog(this);

        SelectPostButton=findViewById(R.id.selectpost);
        UpdatePostButton=findViewById(R.id.updatepost);
        PostDescription=findViewById(R.id.description);
        postref= FirebaseStorage.getInstance().getReference();
        UserRef=FirebaseDatabase.getInstance().getReference().child("Users") ;
        mtoolbar=findViewById(R.id.post_toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Update Post");
        mtoolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });

        SelectPostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gallery=new Intent();
                gallery.setAction(Intent.ACTION_GET_CONTENT);
                gallery.setType("image/");
                startActivityForResult(gallery,gallerypic);
            }
        });
        UpdatePostButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validatepost();
            }
        });
    }

    private void validatepost() {

        description_post=PostDescription.getText().toString();
        if(imageUri==null)
        {
            Toast.makeText(PostActivity.this,"plz select an image..",Toast.LENGTH_LONG).show();

        }
        else if(description_post.isEmpty())
        {
            Toast.makeText(PostActivity.this,"plz write something about your post",Toast.LENGTH_LONG).show();
        }
        else
        {
            StoreImageToStorage();
        }
    }
    private void StoreImageToStorage() {
        Calendar date=Calendar.getInstance();
        SimpleDateFormat currentdate=new SimpleDateFormat("dd-MMMM-yyyy");
        savecurrdate=currentdate.format(date.getTime());

        Calendar time=Calendar.getInstance();
        SimpleDateFormat currenttime=new SimpleDateFormat( "HH:mm");
        savecurrtime=currenttime.format(time.getTime());
        postname=savecurrdate+savecurrtime;


        userid=mauth.getCurrentUser().getUid();
        final StorageReference filepath=postref.child("postimage").child(userid+postname+".jpg");
        loading.setTitle("Updating your post");
        loading.setMessage("Pleas e Wait!!");
        loading.show();
        loading.setCanceledOnTouchOutside(true);
        filepath.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                filepath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(final Uri uri) {
                        final String downloadurl = uri.toString();
                    //    Toast.makeText(PostActivity.this,downloadurl, Toast.LENGTH_LONG).show();
                        UserRef.child(userid).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists())
                                {
                                    if(dataSnapshot.hasChild("profileimage")) {
                                        profile = dataSnapshot.child("profileimage").getValue().toString();
                                    }
                                    if(dataSnapshot.hasChild("fullname")) {
                                        userfullname= dataSnapshot.child("fullname").getValue().toString();
                                    }
                                    databasepostref=FirebaseDatabase.getInstance().getReference().child("Posts");
                                    HashMap m = new HashMap();
                                    m.put("uid", userid);
                                    m.put("date", savecurrdate);
                                    m.put("time", savecurrtime);
                                    m.put("description", description_post);
                                    m.put("postimage", downloadurl);
                                    m.put("profileimage", profile);
                                    m.put("fullname", userfullname);
                                    m.put("postid",userid+postname);
                                    databasepostref.child(userid+postname).updateChildren(m).addOnCompleteListener(new OnCompleteListener() {
                                        @Override
                                        public void onComplete(@NonNull Task task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(PostActivity.this, "post is updated successfully ", Toast.LENGTH_LONG).show();

                                            } else {
                                                Toast.makeText(PostActivity.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                    loading.dismiss();
                                }
                                else
                                {
                                    Toast.makeText(PostActivity.this, "Error: " , Toast.LENGTH_LONG).show();
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
                    }

                });
            }

        });
    }

    @Override
    protected void onActivityResult(int requestCode,int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == gallerypic){
            imageUri = data.getData();
            SelectPostButton.setImageURI(imageUri);

         }
    }

};
