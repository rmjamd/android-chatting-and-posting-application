package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Adapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChatActivity extends AppCompatActivity {

    String friendid,userid;
    private Toolbar mtoolbar;
    private ImageButton sendimage,sendmessage;
    private RecyclerView messagelist;
    private EditText messagetext;
    DatabaseReference friend_ref,userref,messageref;
    private TextView status;
    final  private  List<Messages> list= new ArrayList<>();
    private MessageAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        friendid=getIntent().getExtras().get("userid").toString();
        userid= FirebaseAuth.getInstance().getCurrentUser().getUid();
        friend_ref= FirebaseDatabase.getInstance().getReference().child("Users").child(friendid);
        //userref=FirebaseDatabase.getInstance().getReference().child();
        messageref=FirebaseDatabase.getInstance().getReference().child("Messages");
        Initilize();
        sendmessage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                send_message();
            }
        });
        FetchMessage();
        messagelist.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int left, int top, int right, int bottom, int oldLeft, int oldTop, int oldRight, int oldBottom) {
                if(bottom<oldBottom)
                {
                    messagelist.scrollBy(0,oldBottom-bottom);
                }
            }
        });

    }

    private void FetchMessage() {
        messageref.child(userid).child(friendid).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                if(dataSnapshot.exists())
                {
                    Messages m=dataSnapshot.getValue(Messages.class);
            //        Toast.makeText(ChatActivity.this, m.fm, Toast.LENGTH_SHORT).show();
                    messagelist.smoothScrollToPosition(messagelist.getAdapter().getItemCount());
                    list.add(m);
                    adapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void send_message() {
        String text=messagetext.getText().toString();
        if(text.isEmpty())
        {
            Toast.makeText(this, "Please, Enter Some Text", Toast.LENGTH_SHORT).show();
        }
        else
        {
             String key=messageref.child(userid).child(friendid).push().getKey();
             String senderref=userid+"/"+friendid+"/"+key;
             String receiverref=friendid+"/"+userid+"/"+key;
            Calendar date=Calendar.getInstance();
            SimpleDateFormat currentdate=new SimpleDateFormat("dd-MMMM-yyyy");
            String savecurrdate=currentdate.format(date.getTime());

            Calendar time=Calendar.getInstance();
            SimpleDateFormat currenttime=new SimpleDateFormat( "HH:mm");
            String savecurrtime=currenttime.format(time.getTime());
            Map m=new HashMap();
            m.put("date",savecurrdate);
            m.put("time",savecurrtime);
            m.put("from",userid);
            m.put("message",text);
            m.put("type","text");

            Map mp=new HashMap();
            mp.put(senderref,m);
            mp.put(receiverref,m);
            messageref.updateChildren(mp).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful())
                    {
                        messagetext.setText("");
                    }
                    else
                    {
                        Toast.makeText(ChatActivity.this, "Error: "+task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });



        }
    }

    private void Initilize() {
        mtoolbar=findViewById(R.id.chat_toolbar);
        setSupportActionBar(mtoolbar);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        mtoolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });
        status=findViewById(R.id.chat_status);
        sendimage=findViewById(R.id.chat_send_image);
        sendmessage=findViewById(R.id.chat_send_message);
        messagetext=findViewById(R.id.chat_text);
        messagelist=findViewById(R.id.chat_list);
        messagelist.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);
        messagelist.setLayoutManager(linearLayoutManager);
        final ImageView img;
        friend_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    final ImageView img=findViewById(R.id.chat_image);
                    final TextView t=findViewById(R.id.chat_username);
                    final String image=dataSnapshot.child("profileimage").getValue().toString();
                    final String username=dataSnapshot.child("username").getValue().toString();
                    String stat=dataSnapshot.child("userstate").child("status").getValue().toString();
                    String date=dataSnapshot.child("userstate").child("date").getValue().toString();
                    String time=dataSnapshot.child("userstate").child("time").getValue().toString();
                    if(stat.equals("online"))
                    {
                        status.setText("online");
                    }
                    else
                    {
                        status.setText("Last seen "+time+" "+date);
                    }
                    t.setText(username);
                    Picasso.get().load(image).placeholder(R.drawable.profile).into(img);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        adapter=new MessageAdapter(list);
        messagelist.setAdapter(adapter);
    }

    @Override
    protected void onStop() {
        super.onStop();

    }
}
