package com.example.nevigationview;

import androidx.annotation.FractionRes;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;

public class FriendsActivity extends AppCompatActivity {

    private RecyclerView friendlist;
    FirebaseRecyclerAdapter<Friends, FriendListHolder> adapter;
    Query query;
    String uid;
    FirebaseAuth mauth;
    DatabaseReference userref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);
        mauth=FirebaseAuth.getInstance();
        uid= mauth.getCurrentUser().getUid();
        userref=FirebaseDatabase.getInstance().getReference().child("Users");
        query= FirebaseDatabase.getInstance().getReference().child("Friends").child(uid);
        friendlist = findViewById(R.id.mutual_friend_list);
        friendlist.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        friendlist.setLayoutManager(linearLayoutManager);
        setFriendList();


    }

    private void setFriendList() {
        FirebaseRecyclerOptions<Friends> options=new FirebaseRecyclerOptions.Builder<Friends>().setQuery(query, new SnapshotParser<Friends>() {
            @NonNull
            @Override
            public Friends parseSnapshot(@NonNull DataSnapshot snapshot) {

                return new Friends(snapshot.child("date").getValue().toString());
            }
        }).build();
        adapter=new FirebaseRecyclerAdapter<Friends, FriendListHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull final FriendListHolder holder, int position, @NonNull Friends model) {
                holder.setDate(model.getDate());
                final String friendid=getRef(position).getKey();
                FirebaseDatabase.getInstance().getReference().child("Users").child(friendid).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull final DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists())
                        {
                            final String username=dataSnapshot.child("fullname").getValue().toString();
                            holder.setProfileimage(dataSnapshot.child("profileimage").getValue().toString());
                            holder.setFullname(username);
                            holder.mView.findViewById(R.id.all_user_online).setVisibility(View.INVISIBLE);
                            if(dataSnapshot.child("userstate").child("status").getValue().toString().equals("online"))
                            {
                                holder.setStatus();
                            }

                            holder.mView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    CharSequence options[]=new CharSequence[]
                                            {
                                                    username+"'s Profile",
                                                    "message"
                                            };
                                    AlertDialog.Builder ab=new AlertDialog.Builder(FriendsActivity.this);
                                    ab.setTitle("Select Option");
                                    ab.setItems(options, new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            if(which==0)
                                            {
                                                Intent i=new Intent(FriendsActivity.this,PersonProfileActivity.class);
                                                i.putExtra("userid",friendid);
                                                startActivity(i);
                                            }
                                            else
                                            {
                                                Intent i=new Intent(FriendsActivity.this,ChatActivity.class);
                                                i.putExtra("userid",friendid);
                                                startActivity(i);

                                            }
                                        }
                                    });
                                    AlertDialog a=ab.create();
                                    a.show();
                                }
                            });


                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
            @NonNull
            @Override
            public FriendListHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.all_users_display_layout, parent, false);
                return new FriendListHolder(view);
            }
        };
        friendlist.setAdapter(adapter);
    }

    public static class FriendListHolder extends RecyclerView.ViewHolder {
        View mView;

        public FriendListHolder(View itemView) {
            super(itemView);
            mView = itemView;

        }
        public void setDate(String date) {
            TextView username = (TextView) mView.findViewById(R.id.all_user_status);
            username.setText("friend since "+date);
        }
        public void setStatus() {
            ImageView im=(ImageView)mView.findViewById(R.id.all_user_online);
            im.setVisibility(View.VISIBLE);
        }
        public void setFullname(String fullname)
        {
            TextView username = (TextView) mView.findViewById(R.id.all_user_fullname);
            username.setText(fullname);
        }
        public void setProfileimage(String profileimage)
        {
            CircleImageView image = (CircleImageView) mView.findViewById(R.id.all_user_profile_image);
            Picasso.get().load(profileimage).placeholder(R.drawable.profile).into(image);
        }

    }

    @Override
    protected void onStart() {
        super.onStart();
        updatestatus("online");
        adapter.startListening();

    }

    @Override
    protected void onStop() {
        super.onStop();
        updatestatus("offline");
        adapter.stopListening();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        updatestatus("offline");
    }

    private void updatestatus(String s)
    {
        Calendar date=Calendar.getInstance();
        SimpleDateFormat currentdate=new SimpleDateFormat("dd-MMMM-yyyy");
        String savecurrdate=currentdate.format(date.getTime());

        Calendar time=Calendar.getInstance();
        SimpleDateFormat currenttime=new SimpleDateFormat( "HH:mm a");
        String savecurrtime=currenttime.format(time.getTime());
        Map m =new HashMap<String,String>();
        m.put("date",savecurrdate);
        m.put("time",savecurrtime);
        m.put("status",s);
        String userid=mauth.getCurrentUser().getUid();
        userref.child(userid).child("userstate").updateChildren(m);
    }
}
