package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

public class SetupActivity extends AppCompatActivity {

    private EditText UserName,FullName,CountryName;
    private Button Save;
    private CircleImageView ProfileImage;
    private FirebaseAuth mauth;
    private DatabaseReference UserRef;
    private StorageReference ProfileReference;
    String currentid;
    final static int gallerypic=1;
    Uri imageUri;
    private ProgressDialog loading;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);
        mauth=FirebaseAuth.getInstance();
        currentid=mauth.getCurrentUser().getUid();
        UserRef=FirebaseDatabase.getInstance().getReference().child("Users").child(currentid);

        loading=new ProgressDialog(this);

        UserName=findViewById(R.id.username);
        FullName=findViewById(R.id.fullname);
        ProfileImage=findViewById(R.id.profile);
        CountryName=findViewById(R.id.country);
        ProfileReference= FirebaseStorage.getInstance().getReference().child("profileimage");  ///creating firebase storage named as profile image
        Save=findViewById(R.id.save);
        Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SaveAccountInfo();
            }
        });
        ProfileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent gallery=new Intent();
                gallery.setAction(Intent.ACTION_GET_CONTENT);
                gallery.setType("image/");
                startActivityForResult(gallery,gallerypic);
            }
        });

        UserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {

                    String image=dataSnapshot.child("profileimage").getValue().toString();
                    Picasso.get().load(image).placeholder(R.drawable.profile).into(ProfileImage);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
    @Override
    protected void onActivityResult(int requestCode,int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == gallerypic){
            imageUri = data.getData();
            loading.setTitle("Profile Image");
            loading.setMessage("Please wait, while we updating your profile image...");
            loading.show();
            loading.setCanceledOnTouchOutside(true);

            ProfileImage.setImageURI(imageUri);
            final StorageReference filePath = ProfileReference.child(currentid + ".jpg");

            filePath.putFile(imageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    filePath.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(final Uri uri) {
                            final String downloadUrl = uri.toString();
                            UserRef.child("profileimage").setValue(downloadUrl).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        //Loading image using Picasso
                                        Picasso.get().load(downloadUrl).placeholder(R.drawable.profile).into(ProfileImage);
                                        Toast.makeText(SetupActivity.this, "Image Stored", Toast.LENGTH_SHORT).show();
                                        loading.dismiss();
                                    }
                                    else {
                                        String message = task.getException().getMessage();
                                        Toast.makeText(SetupActivity.this, "Error:" + message, Toast.LENGTH_SHORT).show();
                                        loading.dismiss();
                                    }
                                }
                            });
                        }

                    });

                }


            });




        }
    } 

    private void SaveAccountInfo() {
        String name=UserName.getText().toString();
        String fullname=FullName.getText().toString();
        String countryname=CountryName.getText().toString();
        if(name.isEmpty())
        {

        }
        else if(fullname.isEmpty())
        {

        }
        else if(countryname.isEmpty())
        {

        }else if(imageUri!=null)
        {

            HashMap m=new HashMap();
            m.put("username",name);
            m.put("fullname",fullname);
            m.put("country",countryname);
            m.put("status","i am using rchat");
            m.put("gender","none");
            m.put("dob","none");
            m.put("relationshipstatus","none");
            UserRef.updateChildren(m).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful())
                    {

                        Toast.makeText(SetupActivity.this,"Your account is created successfully",Toast.LENGTH_LONG).show();
                        loading.dismiss();
                        Intent i=new Intent(SetupActivity.this,MainActivity.class );
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(i);
                        finish();

                    }
                    else
                    {
                        Toast.makeText(SetupActivity.this,"Error: "+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                        loading.dismiss();
                    }
                }
            });
        }
        else
        {
            Toast.makeText(SetupActivity.this,"Please Select Your Profile Image",Toast.LENGTH_LONG).show();
        }

    }

}
