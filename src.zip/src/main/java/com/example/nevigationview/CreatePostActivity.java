package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

public class CreatePostActivity extends AppCompatActivity {

    private ImageView postimage;
    private TextView postdescription;
    private Button deletepostbutton;
    private Button editpostbutton;
    private DatabaseReference clickpostref;
    private String postKey;
    FirebaseAuth mauth;
    private StorageReference poststorageref;
    private String id;
    private String imagename;
    private String des,img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_post);
        postKey=getIntent().getExtras().get("PostKey").toString();
        clickpostref= FirebaseDatabase.getInstance().getReference().child("Posts").child(postKey);
        postimage=(ImageView)findViewById(R.id.click_post_image);
        postdescription=(TextView)findViewById(R.id.click_post_description);
        editpostbutton=(Button)findViewById(R.id.click_post_edit);
        deletepostbutton=(Button)findViewById(R.id.click_post_delete);
        mauth=FirebaseAuth.getInstance();
        id=mauth.getCurrentUser().getUid();
        clickpostref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("description"))
                des=dataSnapshot.child("description").getValue().toString();
                if(dataSnapshot.hasChild("postimage"))
                img=dataSnapshot.child("postimage").getValue().toString();
                if(!img.equals(""))
                {
                    poststorageref=FirebaseStorage.getInstance().getReferenceFromUrl(img);
                    Picasso.get().load(img).placeholder(R.drawable.profile).into(postimage);
                }
                postdescription.setText(des);
                if(postKey.regionMatches(false,0,id,0,id.length()))
                {
                    editpostbutton.setVisibility(View.VISIBLE);
                    deletepostbutton.setVisibility(View.VISIBLE);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });

        deletepostbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                poststorageref.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(!task.isSuccessful())
                            Toast.makeText(CreatePostActivity.this, task.getException().getMessage(),Toast.LENGTH_LONG).show();
                        else
                        {
                            remov_data_one_by_one();
                            Toast.makeText(CreatePostActivity.this,"Post is Deleted Successfully",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(CreatePostActivity.this,MainActivity.class));
                        }
                    }
                });
            }
        });
        editpostbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder ab=new AlertDialog.Builder(CreatePostActivity.this);
                ab.setMessage("Edit");
                final EditText e=new EditText(CreatePostActivity.this);
                e.setText(des);
                ab.setView(e);
                ab.setPositiveButton("UPDATE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        clickpostref.child("description").setValue(e.getText().toString());
                        Toast.makeText(CreatePostActivity.this,"Post is Updated Successfully",Toast.LENGTH_LONG).show();
                        finish();
                    }
                });
                ab.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog a=ab.create();
                a.show();

            }
        });
    }

    private void remov_data_one_by_one() {
        clickpostref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String key=snapshot.getKey().toString();
                    clickpostref.child(key).removeValue();
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}
