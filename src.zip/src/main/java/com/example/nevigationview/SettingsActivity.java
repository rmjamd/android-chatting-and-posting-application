package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class SettingsActivity extends AppCompatActivity {

    private Toolbar mtoolbar;
    FirebaseAuth mauth;
    String userid;
    ImageView profileimage;
    Button status,username,fullname,country,dob,gender,relationship;
    DatabaseReference userref,postref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        mtoolbar=findViewById(R.id.settings_toolbar);
        mauth=FirebaseAuth.getInstance();
        status=findViewById(R.id.settings_status);
        username=findViewById(R.id.settings_username);
        fullname=findViewById(R.id.settings_profilename);
        country=findViewById(R.id.settings_country);
        dob=findViewById(R.id.settings_dob);
        gender=findViewById(R.id.settings_gender);
        relationship=findViewById(R.id.settings_reltionship_status);
        userid=mauth.getCurrentUser().getUid();
        userref=FirebaseDatabase.getInstance().getReference().child("Users").child(userid);
        postref=FirebaseDatabase.getInstance().getReference().child("Posts");
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Settings");
        mtoolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        status.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               update("status");
            }
        });
        username.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update("username");
            }
        });
        fullname.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatefullname("fullname");
            }
        });
        country.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update("country");
            }
        });
        gender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update("gender");
            }
        });
        relationship.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update("relationshipstatus");
            }
        });
        dob.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update("dob");
            }
        });
    }

    private void update(String s) {

        final String s1=s;
        userref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
             String text =dataSnapshot.child(s1).getValue().toString();
                AlertDialog.Builder ab=new AlertDialog.Builder(SettingsActivity.this);
                ab.setTitle( s1.toUpperCase());
                final EditText e=new EditText(SettingsActivity.this);
                e.setText(text);
                ab.setView(e);
                ab.setPositiveButton("UPDATE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        userref.child(s1).setValue(e.getText().toString());
                        Toast.makeText(SettingsActivity.this,"Update Successfull",Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }
                });
                ab.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        dialog.dismiss();
                    }
                });
                AlertDialog a=ab.create();
                a.show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void updatefullname(String s) {

        final String s1=s;
        userref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                String text =dataSnapshot.child(s1).getValue().toString();
                AlertDialog.Builder ab=new AlertDialog.Builder(SettingsActivity.this);
                ab.setTitle( s1.toUpperCase());
                final EditText e=new EditText(SettingsActivity.this);
                e.setText(text);
                ab.setView(e);
                ab.setPositiveButton("UPDATE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        userref.child(s1).setValue(e.getText().toString());
                        postref.orderByChild("uid").startAt(userid).endAt(userid+"\uf8ff").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if(dataSnapshot.exists())
                                {
                                    for(DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                        if(dataSnapshot.hasChild("postid"))
                                        {
                                            String postkey=dataSnapshot.child("postid").getValue().toString();
                                            postref.child(postkey).child("username").setValue(e.getText().toString());
                                        }


                                    }

                                }

                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        Toast.makeText(SettingsActivity.this,"Update Successfull",Toast.LENGTH_LONG).show();
                        dialog.dismiss();
                    }
                });
                ab.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                        dialog.dismiss();
                    }
                });
                AlertDialog a=ab.create();
                a.show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
