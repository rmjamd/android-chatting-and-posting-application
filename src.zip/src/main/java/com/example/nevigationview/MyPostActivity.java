package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.firebase.ui.database.SnapshotParser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyPostActivity extends AppCompatActivity {

    private RecyclerView postList;
    private Toolbar mtoolbar;
    private FirebaseAuth mauth;
    private String userid;
   DatabaseReference userRef;
    FirebaseRecyclerAdapter<Posts, PostsViewHolder> adapter;
    private DatabaseReference postref,likeref;
    boolean flag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_post);
        mauth=FirebaseAuth.getInstance();
        userid=mauth.getCurrentUser().getUid();
        userRef=(FirebaseDatabase.getInstance().getReference().child("Users"));
        postref=(FirebaseDatabase.getInstance().getReference().child("Posts"));
        likeref=(FirebaseDatabase.getInstance().getReference().child("Likes"));
        mtoolbar=findViewById(R.id.mypost_toolbar);
        setSupportActionBar(mtoolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("My Post");
        mtoolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
            }
        });
        postList=(RecyclerView)findViewById(R.id.mypost_list);
        postList.setHasFixedSize(true);
        LinearLayoutManager linearLayoutManager=new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        postList.setLayoutManager(linearLayoutManager);
        DisplayPost();

    }
    private void DisplayPost() {
        Query query = postref.orderByChild("uid").startAt(userid).endAt(userid+"\uf8ff");

        FirebaseRecyclerOptions<Posts> options=new FirebaseRecyclerOptions.Builder<Posts>().setQuery(query, new SnapshotParser<Posts>() {
            @NonNull
            @Override
            public Posts parseSnapshot(@NonNull DataSnapshot snapshot) {
                return new Posts(snapshot.child("uid").getValue().toString(),
                        snapshot.child("date").getValue().toString(),
                        snapshot.child("time").getValue().toString(),
                        snapshot.child("postimage").getValue().toString(),
                        snapshot.child("description").getValue().toString(),
                        snapshot.child("profileimage").getValue().toString(),
                        snapshot.child("fullname").getValue().toString());
            }
        }).build();
        adapter=new FirebaseRecyclerAdapter<Posts,PostsViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull PostsViewHolder holder, int position, @NonNull Posts model) {
                final String postKey=getRef(position).getKey();
                holder.setDate(model.getDate());
                holder.setDescription(model.getDescription());
                holder.setFullname(model.getFullname());
                holder.setPostimage(model.getPostimage());
                holder.setTime(model.getTime());
                holder.setProfileimage(model.getProfileimage());
                holder.setLike(postKey);
                holder.PostImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i=new Intent(MyPostActivity.this,CreatePostActivity.class);
                        i.putExtra("PostKey",postKey);
                        startActivity(i);
                    }
                });

                holder.like.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v)
                    {
                        flag=true;
                        likeref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                if(flag)
                                {
                                    if(dataSnapshot.child(postKey).hasChild(userid))
                                    {
                                        likeref.child(postKey).child(userid).removeValue();
                                        flag=false;
                                    }
                                    else
                                    {
                                        likeref.child(postKey).child(userid).setValue(true);
                                        flag=false;
                                    }
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {
                            }
                        });
                    }
                });
                holder.comment.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i=new Intent(MyPostActivity.this,CommentActivity.class);
                        i.putExtra("PostKey",postKey);
                        startActivity(i);
                    }
                });
            }
            @NonNull
            @Override
            public PostsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view = LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.all_post, parent, false);
                return new PostsViewHolder(view);
            }
        };
        postList.setAdapter(adapter);
    }
    public static class PostsViewHolder extends RecyclerView.ViewHolder
    {
        View mView;
        private ImageView PostImage;
        private ImageButton like,comment;
        private TextView no_of_likes;
        private DatabaseReference likeref;
        private int count;
        String id;
        public PostsViewHolder(View itemView)
        {
            super(itemView);
            mView = itemView;
            like=mView.findViewById(R.id.post_like);
            comment=mView.findViewById(R.id.post_comment);
            no_of_likes=mView.findViewById(R.id.post_like_no);
            likeref=FirebaseDatabase.getInstance().getReference().child("Likes");
            id=FirebaseAuth.getInstance().getCurrentUser().getUid();
        }
        public void setFullname(String fullname)
        {
            TextView username = (TextView) mView.findViewById(R.id.post_username);
            username.setText(fullname);
        }
        public void setLike(String postkey)
        {
            likeref.child(postkey).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if(dataSnapshot.hasChild(id))
                    {
                        count=(int)dataSnapshot.getChildrenCount();
                        like.setImageResource(R.drawable.like);
                        no_of_likes.setText(Integer.toString(count));
                    }
                    else
                    {
                        count=(int)dataSnapshot.getChildrenCount();
                        like.setImageResource(R.drawable.dislike);
                        no_of_likes.setText(Integer.toString(count));
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
        public void setProfileimage(String profileimage)
        {
            CircleImageView image = (CircleImageView) mView.findViewById(R.id.post_profile_image);
            Picasso.get().load(profileimage).placeholder(R.drawable.profile).into(image);
        }
        public void setTime(String time)
        {
            TextView PostTime = (TextView) mView.findViewById(R.id.post_time);
            PostTime.setText("    " + time);
        }
        public void setDate(String date)
        {
            TextView PostDate = (TextView) mView.findViewById(R.id.post_date);
            PostDate.setText("    " + date);
        }
        public void setDescription(String description)
        {
            TextView PostDescription = (TextView) mView.findViewById(R.id.post_description);
            PostDescription.setText(description);
        }
        public void setPostimage(String postimage)
        {
            PostImage = (ImageView) mView.findViewById(R.id.post_image);
            Picasso.get().load(postimage).placeholder(R.drawable.profile).into(PostImage);

        }
    }
    @Override
    protected void onStart() {
        super.onStart();
        adapter.startListening();
    }
    protected void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
