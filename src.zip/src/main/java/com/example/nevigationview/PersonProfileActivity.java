package com.example.nevigationview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class PersonProfileActivity extends AppCompatActivity {
    private ImageView profileimage;
    private TextView username,fullname,status,dob,relationship,country;
    FirebaseAuth mauth;
    DatabaseReference friend_ref,userref,friend_request_ref,mutual_friend_ref;
    String friend_uid;
    String uid;
    Button send,decline;
    private String curr_stat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person_profile);
        friend_uid=getIntent().getExtras().get("userid").toString();
        profileimage=findViewById(R.id.friend_profile_pic);
        username=findViewById(R.id.friend_username);
        fullname=findViewById(R.id.friend_fullname);
        country=findViewById(R.id.friend_country);
        dob=findViewById(R.id.friend_dob);
        relationship=findViewById(R.id.friend_relationship_status);
        status=findViewById(R.id.friend_status);
        mutual_friend_ref=FirebaseDatabase.getInstance().getReference().child("Friends");
        friend_request_ref=FirebaseDatabase.getInstance().getReference().child("FriendRequest");
        mauth=FirebaseAuth.getInstance();
        uid=mauth.getCurrentUser().getUid();
        friend_ref= FirebaseDatabase.getInstance().getReference().child("Users").child(friend_uid);
        userref= FirebaseDatabase.getInstance().getReference().child("Users").child(uid);
        send=findViewById(R.id.send_friend_request);
        decline=findViewById(R.id.cancel_friend_request);
        setallValues();
        decline.setVisibility(View.INVISIBLE);
        decline.setEnabled(false);
        setButtonState();
        if(!uid.equals(friend_uid))
        {
            send.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(curr_stat.equals("not_friend"))
                    {
                        sendFriendRequest();
                    }
                    else if(curr_stat.equals("request_send"))
                    {
                        cancelFriendRequest();
                    }
                    else if(curr_stat.equals("request_receive"))
                    {
                        acceptFriendRequest();
                    }
                    else if(curr_stat.equals("friend"))
                    {
                        unfriend();
                    }
                }
            });
            decline.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(curr_stat.equals("request_receive"))
                    {
                        cancelFriendRequest();
                        curr_stat="not_friend";
                    }
                }
            });
        }
        else
        {
            decline.setVisibility(View.INVISIBLE);decline.setEnabled(false);send.setVisibility(View.INVISIBLE);send.setEnabled(false);
        }
    }

    private void unfriend() {
        mutual_friend_ref.child(uid).child(friend_uid).child("date").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    mutual_friend_ref.child(friend_uid).child(uid).child("date").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                curr_stat="not_friend";
                                Toast.makeText(PersonProfileActivity.this, "unfriend", Toast.LENGTH_SHORT).show();
                                send.setText("Send Friend Request");
                                decline.setVisibility(View.INVISIBLE);
                                decline.setEnabled(false);

                            }
                        }
                    });
                }
            }
        });
    }

    private void acceptFriendRequest() {
        Calendar date=Calendar.getInstance();
        SimpleDateFormat currentdate=new SimpleDateFormat("dd-MMMM-yyyy");
        final String savecurrdate=currentdate.format(date.getTime());
        mutual_friend_ref.child(uid).child(friend_uid).child("date").setValue(savecurrdate).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    mutual_friend_ref.child(friend_uid).child(uid).child("date").setValue(savecurrdate).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                friend_request_ref.child(uid).child(friend_uid).child("request_type").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if(task.isSuccessful())
                                        {
                                            friend_request_ref.child(friend_uid).child(uid).child("request_type").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if(task.isSuccessful())
                                                    {
                                                         curr_stat="friend";
                                                        send.setText("Unfriend");
                                                        decline.setVisibility(View.INVISIBLE);
                                                        decline.setEnabled(false);

                                                    }
                                                }
                                            });
                                        }
                                    }
                                });


                            }
                        }
                    });
                }
            }
        });
    }

    private void cancelFriendRequest() {
        friend_request_ref.child(uid).child(friend_uid).child("request_type").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    friend_request_ref.child(friend_uid).child(uid).child("request_type").removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                Toast.makeText(PersonProfileActivity.this, "cancel", Toast.LENGTH_SHORT).show();
                                curr_stat="not_friend";
                                send.setText("Send Friend Request");
                                decline.setVisibility(View.INVISIBLE);
                                decline.setEnabled(false);

                            }
                        }
                    });
                }
            }
        });

    }
    private void setButtonState() {
        friend_request_ref.child(uid).child(friend_uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    String request_type=dataSnapshot.child("request_type").getValue().toString();
                    if(request_type.equals("send"))
                    {
                        curr_stat="request_send";
                        send.setText("Cancel Friend Request");
                    }
                    else if(request_type.equals("receive"))
                    {
                        curr_stat="request_receive";
                        send.setText("Accept Friend Request");
                        decline.setVisibility(View.VISIBLE);
                        decline.setEnabled(true);
                    }
                }
                else
                {
                    mutual_friend_ref.child(uid).child(friend_uid).child("date").addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists())
                            {
                                curr_stat="friend";
                                send.setText("Unfriend");
                            }
                            else
                            {

                                curr_stat="not_friend";
                                send.setText("Send Friend Request");
                            }
                        }
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });

                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    private void sendFriendRequest() {
        friend_request_ref.child(uid).child(friend_uid).child("request_type").setValue("send").addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    friend_request_ref.child(friend_uid).child(uid).child("request_type").setValue("receive").addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                curr_stat="request_send";
                                send.setText("Cancel Friend Request");
                                decline.setVisibility(View.INVISIBLE);
                                decline.setEnabled(false);

                            }
                        }
                    });
                }
           }
        });
    }

    private void setallValues() {
        friend_ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild("username"))
                    username.setText(dataSnapshot.child("username").getValue().toString());
                if(dataSnapshot.hasChild("fullname"))
                    fullname.setText(dataSnapshot.child("fullname").getValue().toString());
                if(dataSnapshot.hasChild("country"))
                    country.setText("Country:  "+dataSnapshot.child("country").getValue().toString());
                if(dataSnapshot.hasChild("status"))
                    status.setText(dataSnapshot.child("status").getValue().toString());
                if(dataSnapshot.hasChild("dob"))
                    dob.setText("Date of Birth:  "+dataSnapshot.child("dob").getValue().toString());
                if(dataSnapshot.hasChild("relationshipstatus"))
                    relationship.setText("Relationship Status:  "+dataSnapshot.child("relationshipstatus").getValue().toString());
                if(dataSnapshot.hasChild("profileimage"))
                    Picasso.get().load(dataSnapshot.child("profileimage").getValue().toString()).placeholder(R.drawable.profile).into(profileimage);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}









